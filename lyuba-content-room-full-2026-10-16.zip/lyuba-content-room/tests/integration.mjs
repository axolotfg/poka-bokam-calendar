import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {mkdtempSync,rmSync} from 'node:fs';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {DatabaseSync} from 'node:sqlite';
const dir=mkdtempSync(join(tmpdir(),'content-room-'));const origin='http://127.0.0.1:18761';let proc;
async function start(){proc=spawn(process.execPath,['server/start.js'],{env:{...process.env,PORT:'18761',PUBLIC_ORIGIN:origin,DB_PATH:join(dir,'test.sqlite')},stdio:['ignore','pipe','pipe']});for(let i=0;i<80;i++){try{if((await fetch(origin+'/health')).ok)return}catch{}await new Promise(r=>setTimeout(r,50))}throw Error('Server did not start')}
async function stop(){if(proc?.exitCode===null){const p=new Promise(r=>proc.once('exit',r));proc.kill('SIGTERM');await p}}
try{await start();assert((await fetch(origin)).ok);const res=await fetch(origin+'/api/state');const x=await res.json();assert(x.storage&&x.editToken);assert.equal(x.state.schemaRevision,10);assert(x.state.tasks.some(t=>t.id==='shoot-comment-16'));const cookie=res.headers.get('set-cookie').split(';')[0];
const state=structuredClone(x.state);const d=state.days.find(d=>d.date==='2026-10-21');d.date='2026-10-22';state.prepOverrides['day-14-1']={done:false};
const post=async(etag,value)=>fetch(origin+'/api/state',{method:'POST',headers:{origin,cookie,'x-edit-token':x.editToken,'content-type':'application/json'},body:JSON.stringify({etag,state:value,label:'Проверка сохранения'})});
assert.equal((await post(x.etag,state)).status,200);assert.equal((await post(x.etag,x.state)).status,409);let y=await(await fetch(origin+'/api/state')).json();assert.equal(y.state.days.find(d=>d.id===d.id&&d.id==='day-21').date,'2026-10-22');assert.equal(y.state.prepOverrides['day-14-1'].done,false);
assert.equal((await fetch(origin+'/calendar.ics')).status,200);assert.equal((await fetch(origin+'/api/state',{method:'POST',body:'{}'})).status,403);await stop();await start();y=await(await fetch(origin+'/api/state')).json();assert.equal(y.state.days.find(d=>d.id==='day-21').date,'2026-10-22');await stop();const db=new DatabaseSync(join(dir,'test.sqlite'));assert(db.prepare('SELECT count(*) AS n FROM history').get().n>=1);db.close();console.log('PASS: page, initial data 16.10, date saved after reload/restart, unchecked task, stale-write rejection, backup history, calendar feed and request protection')
}finally{await stop();rmSync(dir,{recursive:true,force:true})}
