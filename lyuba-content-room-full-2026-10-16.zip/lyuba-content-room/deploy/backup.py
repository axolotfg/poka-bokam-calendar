#!/usr/bin/env python3
"""Run daily and before updating; SQLite backup includes committed WAL data."""
import sqlite3,sys,datetime,pathlib
source=pathlib.Path(sys.argv[1]); out=pathlib.Path(sys.argv[2]);out.mkdir(parents=True,exist_ok=True)
target=out/('plan-'+datetime.datetime.now(datetime.timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')+'.sqlite')
with sqlite3.connect('file:'+str(source.resolve())+'?mode=ro',uri=True) as src, sqlite3.connect(target) as dst:src.backup(dst)
print(target)
