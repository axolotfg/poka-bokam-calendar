import {DatabaseSync} from 'node:sqlite';
import {createHash} from 'node:crypto';
import {mkdirSync} from 'node:fs';
import {dirname} from 'node:path';
export function createBucket(path){
 mkdirSync(dirname(path),{recursive:true,mode:0o700});
 const db=new DatabaseSync(path);
 db.exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000; CREATE TABLE IF NOT EXISTS objects (key TEXT PRIMARY KEY, body TEXT NOT NULL, etag TEXT NOT NULL); CREATE TABLE IF NOT EXISTS history(id INTEGER PRIMARY KEY, key TEXT NOT NULL, body TEXT NOT NULL, etag TEXT NOT NULL, saved_at TEXT NOT NULL)');
 const rev=b=>'sha256:'+createHash('sha256').update(b).digest('hex');
 return {db,async get(key){const r=db.prepare('SELECT body,etag FROM objects WHERE key=?').get(key);return r?{etag:r.etag,json:async()=>JSON.parse(r.body)}:null},async put(key,body,opt={}){db.exec('BEGIN IMMEDIATE');try{const old=db.prepare('SELECT body,etag FROM objects WHERE key=?').get(key);const cond=opt.onlyIf;if(cond&&((cond.etagMatches&&old?.etag!==cond.etagMatches)||(cond.etagDoesNotMatch==='*'&&old))){db.exec('ROLLBACK');return null}if(old)db.prepare('INSERT INTO history(key,body,etag,saved_at) VALUES(?,?,?,?)').run(key,old.body,old.etag,new Date().toISOString());const etag=rev(body);db.prepare('INSERT INTO objects(key,body,etag) VALUES(?,?,?) ON CONFLICT(key) DO UPDATE SET body=excluded.body,etag=excluded.etag').run(key,body,etag);db.exec('COMMIT');return {etag}}catch(e){db.exec('ROLLBACK');throw e}},close(){db.close()}};
}
