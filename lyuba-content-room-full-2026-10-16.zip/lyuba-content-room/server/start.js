import http from 'node:http';
import {readFileSync} from 'node:fs';
import {resolve} from 'node:path';
import worker from './worker.js';
import {createBucket} from './storage.js';
const bucket=createBucket(process.env.DB_PATH||resolve('data/plan.sqlite'));
const key='content-office/state.json';
if(!await bucket.get(key))await bucket.put(key,readFileSync(new URL('../data/initial-state.json',import.meta.url),'utf8'),{onlyIf:{etagDoesNotMatch:'*'}});
const page=readFileSync(new URL('../index.html',import.meta.url));
const origin=process.env.PUBLIC_ORIGIN||'http://localhost:3000';
const server=http.createServer(async(req,res)=>{try{
 if(req.url==='/'&&req.method==='GET'){res.writeHead(200,{'content-type':'text/html; charset=utf-8','cache-control':'no-store'});return res.end(page)}
 if(req.url==='/health'){res.writeHead(200,{'content-type':'application/json'});return res.end('{"ok":true}')}
 const chunks=[];let size=0;for await(const c of req){size+=c.length;if(size>1500000){res.writeHead(413);res.end();return}chunks.push(c)}
 const headers=new Headers();for(const[k,v]of Object.entries(req.headers))if(v)headers.set(k,Array.isArray(v)?v.join(','):v);
 const init={method:req.method,headers};if(req.method!=='GET'&&req.method!=='HEAD')init.body=Buffer.concat(chunks);
 const response=await worker.fetch(new Request(new URL(req.url,origin),init),{BUCKET:bucket});
 res.writeHead(response.status,Object.fromEntries(response.headers));res.end(Buffer.from(await response.arrayBuffer()));
 }catch(e){console.error('Request failed:',e.message);res.writeHead(500,{'content-type':'application/json'});res.end('{"error":"Ошибка сервера; изменения не подтверждены"}')}});
server.listen(Number(process.env.PORT||3000),process.env.HOST||'127.0.0.1',()=>console.log('Content room listening on port '+(process.env.PORT||3000)));
for(const signal of ['SIGTERM','SIGINT'])process.on(signal,()=>server.close(()=>{bucket.close();process.exit(0)}));
