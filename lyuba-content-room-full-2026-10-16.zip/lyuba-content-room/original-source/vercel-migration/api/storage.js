import { createHash, randomUUID } from 'node:crypto';
import { get, head, put, BlobPreconditionFailedError } from '@vercel/blob';

// The application revision describes the JSON bytes, not a CDN representation.
const revision = body => 'sha256:' + createHash('sha256').update(body).digest('hex');
const tag = value => String(value || '').replace(/^W\//, '').replace(/^"|"$/g, '');
export function createBucket(sdk = { get, head, put }, makeId = randomUUID) {
  async function current(path) {
    for (let attempt = 0; attempt < 3; attempt++) {
      let metadata;
      try { metadata = await sdk.head(path); }
      catch (error) {
        if (error?.name === 'BlobNotFoundError') return null;
        throw error;
      }
      const result = await sdk.get(path, { access: 'private', useCache: false });
      if (!result) continue;
      const body = await new Response(result.stream).text();
      const after = await sdk.head(path);
      if (!metadata.etag || !result.blob?.etag || !after.etag)
        throw new Error('Storage revision unavailable; write stopped');
      // Never pair stale bytes with a fresh write token.
      if (tag(metadata.etag) !== tag(after.etag) || tag(result.blob.etag) !== tag(after.etag)) continue;
      return { body, storageEtag: after.etag, etag: revision(body) };
    }
    throw new Error('Storage returned stale data repeatedly; draft was not overwritten');
  }
  return {
    async get(path) {
      const value = await current(path);
      return value ? { etag: value.etag, json: async () => JSON.parse(value.body) } : null;
    },
    async put(path, body, options = {}) {
      try {
        const value = await current(path);
        const expected = options.onlyIf?.etagMatches;
        if (value ? expected !== value.etag : Boolean(expected)) return null;
        if (value && path === 'content-office/state.json') {
          const state = JSON.parse(value.body);
          await sdk.put('content-office/backups/' + new Date().toISOString().replace(/[:.]/g, '-') + '-v' + (state.version || 0) + '-' + makeId() + '.json', value.body, {
            access: 'private', addRandomSuffix: false, allowOverwrite: false, contentType: 'application/json',
          });
        }
        await sdk.put(path, body, {
          access: 'private', addRandomSuffix: false, allowOverwrite: Boolean(value),
          ...(value ? { ifMatch: value.storageEtag } : {}), contentType: 'application/json',
        });
        return { etag: revision(body) };
      } catch (error) {
        if (error instanceof BlobPreconditionFailedError || ['BlobPreconditionFailedError', 'BlobAlreadyExistsError'].includes(error?.name)) return null;
        console.error('Content persistence stopped', error?.name, error?.message);
        throw error;
      }
    },
  };
}
export const BUCKET = createBucket();
