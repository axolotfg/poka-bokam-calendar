import worker from './worker.js';
import { BUCKET } from './storage.js';

export default async function handler(req, res) {
  const host = req.headers['x-forwarded-host'] || req.headers.host;
  const route = new URL(req.url, 'https://' + host).searchParams.get('route');
  const path = route === 'calendar' ? '/calendar.ics' : '/api/state';
  const headers = new Headers();
  for (const [key, value] of Object.entries(req.headers)) {
    if (value !== undefined) headers.set(key, Array.isArray(value) ? value.join(', ') : value);
  }
  const init = { method: req.method, headers };
  if (req.method !== 'GET' && req.method !== 'HEAD') {
    if (req.body !== undefined) init.body = typeof req.body === 'string' ? req.body : JSON.stringify(req.body);
    else { const parts = []; for await (const part of req) parts.push(part); init.body = Buffer.concat(parts); }
  }
  const response = await worker.fetch(new Request('https://' + host + path, init), { BUCKET });
  res.statusCode = response.status;
  for (const [key, value] of response.headers) res.setHeader(key, value);
  res.end(Buffer.from(await response.arrayBuffer()));
}
